<div class="container-fluid py-1 mb-6 vh-100">
     <div class="row">
         <div class="col-12">

             <div class="row  ">
                 <div class="col-12  m-auto ">
                     <div class="card">
                         <div class="card-body">
                             <form action="">

                                 <div class="border-radius-xl bg-white">
                                     <h5 class="font-weight-bolder mb-2">Create Membership id</h5>

                                     <div class=" "> 

                                         <div class="row mt-3">
                                             <div class="col-12 col-sm-6">
                                                 <div class="input-group input-group-static ">
                                                     <label class=" ">Member Username</label>
                                                     <input class="  form-control" type="text" placeholder="Member Username" />
                                                 </div>
                                             </div>
                                             <div class="col-12 col-sm-6 mt-3 mt-sm-0">
                                                 <div class="input-group input-group-static ">
                                                     <label class=" "> Member Password</label>
                                                     <input class="form-control " type="password">
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                 </div> 

                                 <div class="button-row d-flex mt-4">
                                     <a href="membership_form_list" class="ms-auto mb-0">
                                         <button class="ms-auto mb-0 px-6 btn bg-gradient-dark " type="button" title="submit" >Submit Mail</button></a>
                                 </div>
                             </form>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div> 